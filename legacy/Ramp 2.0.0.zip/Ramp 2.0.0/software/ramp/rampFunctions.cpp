/**
   Copyright 2020 Levente Csóka
**/
#include "ramp.h"
#include <Wire.h>
#include <H3LIS331DL.h>

const int       MIN_VALUE                = -32768;       ///< Minimum value of unsigned int
H3LIS331DL      h3lis;                                   ///< Handler of the Accelerometer

void acquireData(data_t* data)
{
  data->time = millis();

  int16_t x = MIN_VALUE;
  int16_t y = MIN_VALUE;
  int16_t z = MIN_VALUE;
  int16_t gx = MIN_VALUE;
  int16_t gy = MIN_VALUE;
  int16_t gz = MIN_VALUE;
  int16_t lx = MIN_VALUE;
  int16_t ly = MIN_VALUE;
  int16_t lz = MIN_VALUE;

  Wire.beginTransmission(0x18);
  Wire.write(0x28);
  Wire.endTransmission();
  Wire.requestFrom(0x18, 6);
  x = Wire.read() << 8 | Wire.read();
  y = Wire.read() << 8 | Wire.read();
  z = Wire.read() << 8 | Wire.read();
  Wire.endTransmission();
  Wire.beginTransmission(0x68);
  Wire.write(0x43);
  Wire.endTransmission();
  Wire.requestFrom(0x68, 6);
  gx = Wire.read() << 8 | Wire.read();
  gy = Wire.read() << 8 | Wire.read();
  gz = Wire.read() << 8 | Wire.read();
  Wire.endTransmission();
  Wire.beginTransmission(0x68);
  Wire.write(0x3B);
  Wire.endTransmission();
  Wire.requestFrom(0x68, 6);
  lx = Wire.read() << 8 | Wire.read();
  ly = Wire.read() << 8 | Wire.read();
  lz = Wire.read() << 8 | Wire.read();
  Wire.endTransmission();

  data->lx = lx;
  data->ly = ly;
  data->lz = lz;
  data->gx = gx;
  data->gy = gy;
  data->gz = gz;
  data->x = x;
  data->y = y;
  data->z = z;
}

// Sensor setup
int rampSetup() {
  h3lis.init(H3LIS331DL_ODR_400Hz, H3LIS331DL_NORMAL, H3LIS331DL_FULLSCALE_2);
  h3lis.importPara(0, 0, 0);

  Wire.beginTransmission(0x68);
  Wire.write(0x6B);
  Wire.write(0x00);
  Wire.endTransmission();
  return 0;
}
