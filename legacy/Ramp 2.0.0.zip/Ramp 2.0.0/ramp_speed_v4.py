import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import scipy.signal as signal
import struct
import math
import numpy as np

class KalmanFilter:
    def __init__(self, e : float):
        # error in the estimate
        self.eest = e
        # error in the measurement
        self.emear = e
        # previous estimate
        self.pest = None

    def calc(self, m : float):
        if self.pest is None:
            self.pest = m
            return m
        else: 
            kg = self.eest/(self.eest+self.emear)
            cest = self.pest + (kg * (m-self.pest))
            self.eest = (1-kg)*self.eest
            self.pest = cest
            return cest



c = []
x = []
y = []
z = []
lx = []
ly = []
lz = []
gx = []
gy = []
gz = []


kalmanX = KalmanFilter(0.830078125/2)
kalmanY = KalmanFilter(1.4892578125/2)
kalmanZ = KalmanFilter(1.8310546875/2)

kalmanGX = KalmanFilter(1.979827880859375)
kalmanGY = KalmanFilter(3.57818603515625)
kalmanGZ = KalmanFilter(0.46539306640625)

def processFile(filename : str):
    with open(filename, "rb") as f:
        blockCounter = 0
        while True:
            index = 0
            block = f.read(512)
            if block[0] == 0x00:
                break
            blockCounter = blockCounter+1
            count = int.from_bytes(block[index :index+2], "little", signed=True)
            index = index+2
            overrun = int.from_bytes(block[index :index+2], "little", signed=True)
            index = index+2
            for _ in range(count):

                # Accelerometer:
                # Gives back an int16_t which is 16 bit: −32768, +32767
                # The scaling is set to +/- 100G

                # Gyroscope:
                # Gives back an int16_t which is 16 bit: −32768, +32767
                # The scaling is set to +/- 250°/s

                # Accelerometer:
                # Gives back an int16_t which is 16 bit: −32768, +32767
                # The scaling is set to +/- 16G

                c.append(struct.unpack('i', block[index: index+4])[0])
                index = index + 4

                tx = int.from_bytes(block[index :index+2], "little", signed=True)
                # x.append(kalmanX.calc((float(tx*(100.0/32768.0)))+0.16987753882915174))
                tx = float(tx*(100.0/32768.0))+0.16987753882915174
                index = index+2

                ty = int.from_bytes(block[index :index+2], "little", signed=True)
                ty = float(ty*(100.0/32768.0))+0.0972624747983871
                # y.append(kalmanY.calc((float(ty*(100.0/32768.0)))+0.0972624747983871))
                index = index+2

                tz = int.from_bytes(block[index :index+2], "little", signed=True)
                tz = float(tz*(100.0/32768.0))-0.7021808145721776
                # z.append(kalmanZ.calc((float(tz*(100.0/32768.0)))-0.7021808145721327))
                index = index+2


                # Accelerometer 2:
                tlx = int.from_bytes(block[index :index+2], "little", signed=True)
                tlx = float(tlx*(2.0/32768.0))-0.019927005491394926
                # x.append(kalmanX.calc((float(tx*(100.0/32768.0)))+0.16987753882915174))
                index = index+2

                tly = int.from_bytes(block[index :index+2], "little", signed=True)
                tly = float(tly*(2.0/32768.0))-0.008043283656023551
                # y.append(kalmanY.calc((float(ty*(100.0/32768.0)))+0.0972624747983871))
                index = index+2

                tlz = int.from_bytes(block[index :index+2], "little", signed=True)
                tlz = float(tlz*(2.0/32768.0))+0.00893846594769021
                # z.append(kalmanZ.calc((float(tz*(100.0/32768.0)))-0.7021808145721327))
                index = index+2

                x.append(tlx if abs(tlx) < 2.0 else tx)
                y.append(tly if abs(tly) < 2.0 else ty)
                z.append(tlz if abs(tlz) < 2.0 else tz)

                # Gyroscope:
                tgx = int.from_bytes(block[index :index+2], "little", signed=True)
                # gx.append(kalmanGX.calc(float(tgx*(250.0/32768.0))-1.9086213379635464))
                gx.append((float(tgx*(250.0/32768.0))-1.9086213379635464))
                index = index+2

                tgy = int.from_bytes(block[index :index+2], "little", signed=True)
                # gy.append(kalmanGY.calc(float(tgy*(250.0/32768.0))+3.7417360531386508))
                gy.append((float(tgy*(250.0/32768.0))+3.7417360531386508))
                index = index+2

                tgz = int.from_bytes(block[index :index+2], "little", signed=True)
                # gz.append(kalmanGZ.calc(float(tgz*(250.0/32768.0))+0.23863278551910655))
                gz.append(-(float(tgz*(250.0/32768.0))+0.23863278551910655))
                index = index+2

        print("Blocks read: ", blockCounter)

def rotate(x: float, y: float, z:float):
    rx = np.array([[           1,           0,           0, 0],
                   [           0, math.cos(x),-math.sin(x), 0],
                   [           0, math.sin(x), math.cos(x), 0],
                   [           0,           0,           0, 1]])
    ry = np.array([[ math.cos(y),           0, math.sin(y), 0],
                   [           0,           1,           0, 0],
                   [-math.sin(y),           0, math.cos(y), 0],
                   [           0,           0,           0, 1]])
    rz = np.array([[ math.cos(z),-math.sin(z),           0, 0],
                   [ math.sin(z), math.cos(z),           0, 0],
                   [           0,           0,           1, 0],
                   [           0,           0,           0, 1]])
    return np.matmul(np.matmul(rx,ry),rz)

def translate(x: float, y: float, z:float):
    return np.array([[1, 0, 0, x],
                     [0, 1, 0, y],
                     [0, 0, 1, z],
                     [0, 0, 0, 1]])


processFile("resources/log.bin")

N  = 2    # Filter order
Wn = 8.0/(0.5*250)  # Cutoff frequency
B, A = signal.butter(N, Wn)
# Second, apply the filter
x = signal.filtfilt(B,A, x)
y = signal.filtfilt(B,A, y)
z = signal.filtfilt(B,A, z)


# sum
s = [ math.sqrt(pow(x[i],2) + pow(y[i],2) + pow(z[i],2)) for i in range(len(x))]

# Calculate the movement in cm from delta time and acceleration
dx = [] # delta x
dy = [] # delta y
dz = [] # delta z
rx = [] # delta rotation x
ry = [] # delta rotation y
rz = [] # delta rotation z

for i in range(len(c)-1):
    # elapsed time in ms
    dt = c[i+1]-c[i]

    # calculate the delta distance from the elapsed time and acceleration
    # this calculation is not in relation to the previous
    dx.append(0.5*(x[i]*9.80665)*pow((dt/1000.0), 2)*100)
    dy.append(0.5*(y[i]*9.80665)*pow((dt/1000.0), 2)*100)
    dz.append(0.5*(z[i]*9.80665)*pow((dt/1000.0), 2)*100)

    # calculate the delta rotation from the elapsed time and rotaion speed
    # this calculation is not in relation to the previous
    rx.append(gx[i] * (dt/1000.0))
    ry.append(gy[i] * (dt/1000.0))
    rz.append(gz[i] * (dt/1000.0))

# compensate for the last delta
dx.append(0)
dy.append(0)
dz.append(0)
rx.append(0)
ry.append(0)
rz.append(0)

fig = plt.figure(num="Path Traceback")
ax = fig.add_subplot(111, projection='3d')

# previous matrix
pm = np.array([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])

# final locations
fx = []
fy = []
fz = []

fig.show()
# calculate the final position based on translations and rotations
for i in range(len(x)):
    tm = translate(dx[i], dy[i], dz[i])
    rm = rotate(math.radians(rx[i]),math.radians(ry[i]),math.radians(rz[i]))
    trans_m = np.matmul(rm,tm)
    gv = np.array([0, 0, (0.5*(1.0000000000000449*9.80665)*pow(( (c[i+1]-c[i] if i < len(c)-1 else 4) /1000.0), 2)*100)])
    trans_m[2][3] -=gv[2]
    pm = np.matmul(pm, trans_m)
    fp = [0,0,0,1]
    fp = pm.dot(fp)
    fx.append(fp[0])
    fy.append(fp[1])
    fz.append(fp[2])

# derivative
d = [ s[i+1]-s[i] for i in range(len(s)-1)]
d.append(0)

# derivative peaks
dp = [ 1 if d[i] > 1 or d[i] < -1 else 0 for i in range(len(d))]
ff = [ 0 for i in range(len(s))]
limit = 0.5
fstart = 0
fend = 0
skipTo = 0
for i in range(len(s)):
    if skipTo > i:
        continue
    elif s[i] < limit:
        """Freefalling"""
        fstart = i
        fend = i
        j = i
        while j >= 0 and d[j] < 0 :
            ff[j] = 5
            j -=1
        ff[j+1] = 15
        fstart = j+1
        
        j = i
        while j < len(dp)-1 and s[j] < limit:
            ff[j] = 5
            j += 1
        k = j
        while k > i and d[k] > 0:
            ff[k] = 0
            k -= 1
        fend = k+1
        skipTo = j
        ff[k+1] = 15
        ftime = (c[fend]-c[fstart])
        fheight = 0.5 * 9.80665 * pow(ftime/1000.0,2)
        if fend != fstart:
            print("Freefall:{}-{} {}ms {}cm".format(c[fstart],c[fend], ftime, fheight*100.0))


ax.plot3D([-1.5, 1.5], [0, 0], [0, 0], 'red')
ax.plot3D([0, 0], [-1.5, 1.5], [0, 0], 'green')
ax.plot3D([0, 0], [0, 0], [-1.5, 1.5], 'blue')
ax.plot3D(fx ,fy, fz, 'gray', label="trace")
ax.set_xlabel('X axis')
ax.set_ylabel('Y axis')
ax.set_zlabel('Z axis')

plt.legend()

plt.show() 
